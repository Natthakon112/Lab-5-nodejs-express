const listEl =
    document.getElementById("studentList");

const formEl =
    document.getElementById("addForm");

const nameEl =
    document.getElementById("nameInput");

const errEl =
    document.getElementById("errorMsg");

const countEl =
    document.getElementById("studentCount");

const searchEl =
    document.getElementById("searchInput");

const searchBtn =
    document.getElementById("searchBtn");

const clearBtn =
    document.getElementById("clearBtn");


// ========================================
// Load Students
// ========================================

async function loadStudents(query = "") {

    try {

        let url = "/api/students";


        // ถ้ามีคำค้นหา
        if (query.trim() !== "") {

            url +=
                `?q=${encodeURIComponent(query.trim())}`;

        }


        const res = await fetch(url);

        const students = await res.json();


        listEl.innerHTML = "";


        // จำนวนข้อมูล
        countEl.textContent =
            students.length;


        // ไม่พบข้อมูล
        if (students.length === 0) {

            const empty =
                document.createElement("li");

            empty.className = "empty";

            empty.textContent =
                "ไม่พบข้อมูลนิสิต";

            listEl.appendChild(empty);

            return;
        }


        // แสดงข้อมูล
        for (const student of students) {

            const li =
                document.createElement("li");

            li.className =
                "student-item";


            // Student information
            const info =
                document.createElement("div");

            info.className =
                "student-info";


            // Avatar
            const avatar =
                document.createElement("div");

            avatar.className =
                "student-avatar";

            avatar.textContent =
                student.name
                    .charAt(0)
                    .toUpperCase();


            // Text
            const text =
                document.createElement("div");


            const name =
                document.createElement("div");

            name.className =
                "student-name";

            name.textContent =
                student.name;


            const id =
                document.createElement("div");

            id.className =
                "student-id";

            id.textContent =
                `Student ID: ${student.id}`;


            text.appendChild(name);

            text.appendChild(id);


            info.appendChild(avatar);

            info.appendChild(text);


            // Delete button
            const btn =
                document.createElement("button");

            btn.className =
                "delete-btn";

            btn.textContent =
                "Delete";


            btn.onclick = () => {

                deleteStudent(student.id);

            };


            li.appendChild(info);

            li.appendChild(btn);

            listEl.appendChild(li);

        }

    }

    catch (error) {

        console.error(error);

        errEl.textContent =
            "ไม่สามารถเชื่อมต่อกับ API ได้";

    }
}



// ========================================
// Add Student
// ========================================

async function addStudent(name) {

    errEl.textContent = "";

    name = name.trim();


    if (!name) {

        errEl.textContent =
            "กรุณากรอกชื่อนิสิต";

        return;
    }


    try {

        const res =
            await fetch("/api/students", {

                method: "POST",

                headers: {
                    "Content-Type":
                        "application/json"
                },

                body: JSON.stringify({
                    name: name
                })

            });


        if (!res.ok) {

            const data =
                await res.json();

            errEl.textContent =
                data.error ||
                "เกิดข้อผิดพลาด";

            return;
        }


        nameEl.value = "";

        nameEl.focus();


        await loadStudents();

    }

    catch (error) {

        console.error(error);

        errEl.textContent =
            "ไม่สามารถเชื่อมต่อกับ API ได้";

    }
}



// ========================================
// Delete Student
// ========================================

async function deleteStudent(id) {

    try {

        const res =
            await fetch(
                `/api/students/${id}`,
                {
                    method: "DELETE"
                }
            );


        if (res.status === 204) {

            await loadStudents();

        }

        else {

            const data =
                await res.json();

            alert(
                data.error ||
                "ไม่สามารถลบนิสิตได้"
            );

        }

    }

    catch (error) {

        console.error(error);

        alert(
            "ไม่สามารถเชื่อมต่อกับ API ได้"
        );

    }
}



// ========================================
// Search
// ========================================

searchBtn.addEventListener(
    "click",
    () => {

        loadStudents(
            searchEl.value
        );

    }
);



// กด Enter เพื่อค้นหา

searchEl.addEventListener(
    "keydown",
    (event) => {

        if (event.key === "Enter") {

            event.preventDefault();

            loadStudents(
                searchEl.value
            );

        }

    }
);



// ========================================
// Clear Search
// ========================================

clearBtn.addEventListener(
    "click",
    () => {

        searchEl.value = "";

        loadStudents();

    }
);



// ========================================
// Add Form
// ========================================

formEl.addEventListener(
    "submit",
    (event) => {

        event.preventDefault();

        addStudent(
            nameEl.value
        );

    }
);



// ========================================
// Initial Load
// ========================================

loadStudents();