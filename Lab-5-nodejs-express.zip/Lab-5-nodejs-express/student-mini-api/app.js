const express = require("express");
const path = require("path");

const app = express();
const PORT = 3000;

// รับ JSON
app.use(express.json());

// เปิดหน้าเว็บจาก public
app.use(express.static(path.join(__dirname, "public")));

// ข้อมูลนิสิต
let students = [
    { id: 1, name: "Marty" },
    { id: 2, name: "Jenny" }
];

let nextId = 3;


// ========================================
// GET /api/students
// ดูนิสิตทั้งหมด + Search ?q=
// ========================================

app.get("/api/students", (req, res) => {

    const q = req.query.q;

    // ไม่มี q → คืนข้อมูลทั้งหมด
    if (!q) {
        return res.json(students);
    }


    // ถ้า q เป็นตัวเลข → ค้นหาด้วย ID
    if (!isNaN(q)) {

        const id = Number(q);

        const result = students.filter(
            student => student.id === id
        );

        return res.json(result);
    }


    // ถ้า q เป็นข้อความ → ค้นหาด้วยชื่อ
    const keyword = q.toLowerCase();

    const result = students.filter(
        student =>
            student.name
                .toLowerCase()
                .includes(keyword)
    );

    res.json(result);
});


// ========================================
// GET /api/students/:id
// ดูข้อมูลนิสิต 1 คน
// ========================================

app.get("/api/students/:id", (req, res) => {

    const id = Number(req.params.id);

    const student = students.find(
        student => student.id === id
    );


    if (!student) {

        return res.status(404).json({
            error: "student not found"
        });

    }


    res.json(student);
});


// ========================================
// POST /api/students
// เพิ่มนิสิต
// ========================================

app.post("/api/students", (req, res) => {

    const { name } = req.body;


    if (!name || name.trim() === "") {

        return res.status(400).json({
            error: "name is required"
        });

    }


    const newStudent = {
        id: nextId++,
        name: name.trim()
    };


    students.push(newStudent);


    res.status(201).json(newStudent);
});


// ========================================
// DELETE /api/students/:id
// ลบนิสิต
// ========================================

app.delete("/api/students/:id", (req, res) => {

    const id = Number(req.params.id);


    const index = students.findIndex(
        student => student.id === id
    );


    if (index === -1) {

        return res.status(404).json({
            error: "student not found"
        });

    }


    students.splice(index, 1);


    res.status(204).send();
});


// ========================================
// Start Server
// ========================================

app.listen(PORT, () => {

    console.log(
        `Server running at http://localhost:${PORT}`
    );

});